package syw.mp3player;

import java.util.ArrayList;

import syw.mp3player.util.DataUtils;
import syw.mp3player.util.MusicBC;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.LocalActivityManager;
import android.app.TabActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.atguigu.mp3player3.R;

@SuppressWarnings("deprecation")
public class MainActivity extends TabActivity {

	
	private LocalActivityManager manager;
	private TabHost tabHost;
	private ViewPager viewPager;
	public static TextView footer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main);

		footer = (TextView) findViewById(R.id.text_footet_playingMusic);
		
		manager = new LocalActivityManager(this, true);
		manager.dispatchCreate(savedInstanceState);

		this.loadTabHost();
		this.loadViewPager();

		tabHost.setCurrentTab(1);

		footer.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this,
						PlayMusicActivity.class));
			}
		});
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		if (PlayService.playStatus != 0) {
			footer.setText(PlayService.name);//���ײ������������ָ���
		}
		
	}

	public void loadTabHost() {
		tabHost = getTabHost();
		tabHost.addTab(tabHost
				.newTabSpec("myMusic")
				.setIndicator("�ҵ�����",
						getResources().getDrawable(R.drawable.xin_big))
				.setContent(new Intent(MainActivity.this, MyMusicListActivity.class)));
		tabHost.addTab(tabHost
				.newTabSpec("allMusic")
				.setIndicator("���и���",
						getResources().getDrawable(R.drawable.all_tab))
				.setContent(new Intent(MainActivity.this, AllMusicListActivity.class)));
		tabHost.addTab(tabHost
				.newTabSpec("playingMusic")
				.setIndicator("�����б�",
						getResources().getDrawable(R.drawable.play_tab))
				.setContent(new Intent(MainActivity.this, PlayMusicListActivity.class)));
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {

			public void onTabChanged(String tabId) {
				if (tabId.equals("myMusic")) {
					viewPager.setCurrentItem(0);
				}
				if (tabId.equals("allMusic")) {
					viewPager.setCurrentItem(1);
				}
				if (tabId.equals("playingMusic")) {
					viewPager.setCurrentItem(2);
				}
			}
		});
	}

	public void loadViewPager() {

		viewPager = (ViewPager) findViewById(R.id.viewPager);
		final ArrayList<View> list = new ArrayList<View>();
		list.add(getView("myMusic", new Intent(MainActivity.this,
				MyMusicListActivity.class)));
		list.add(getView("allMusic", new Intent(MainActivity.this,
				AllMusicListActivity.class)));
		list.add(getView("playingMusic", new Intent(MainActivity.this,
				PlayMusicListActivity.class)));

		viewPager.setAdapter(new PagerAdapter() {

			@Override
			public void destroyItem(View arg0, int arg1, Object arg2) {
				viewPager.removeView(list.get(arg1));
			}

			@Override
			public Object instantiateItem(View arg0, int arg1) {
				((ViewPager) arg0).addView(list.get(arg1));
				return list.get(arg1);
			}

			@Override
			public boolean isViewFromObject(View arg0, Object arg1) {
				return arg0 == arg1;
			}

			@Override
			public int getCount() {
				return list.size();
			}

			@Override
			public void finishUpdate(View arg0) {
			}

			@Override
			public void restoreState(Parcelable arg0, ClassLoader arg1) {
			}

			@Override
			public Parcelable saveState() {
				return null;
			}

			@Override
			public void startUpdate(View arg0) {
			}
		});

		viewPager.setOnPageChangeListener(new OnPageChangeListener() {

			public void onPageSelected(int arg0) {
				tabHost.setCurrentTab(arg0);
			}

			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}

			public void onPageScrollStateChanged(int arg0) {
			}
		});
	}

	private View getView(String id, Intent intent) {
		return manager.startActivity(id, intent).getDecorView();
	}
	
}
