package syw.mp3player;

import java.util.List;

import syw.mp3player.bean.MP3Music;
import syw.mp3player.util.DataUtils;
import syw.mp3player.util.PlayUtils;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.atguigu.mp3player3.R;
/**
 * ���ֲ����б�Activity
 * @author xfzhang
 *
 */
public class PlayMusicListActivity extends Activity {

	private ListView playMusicList;
	public static MyListAdapter myListAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.playmusic_list_layout);

		init();
	}

	/**
	 * ��ʼ��
	 */
	private void init() {
		playMusicList = (ListView) findViewById(R.id.playMusicList);
		myListAdapter = new MyListAdapter();
		playMusicList.setAdapter(myListAdapter);
		playMusicList.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parentView, View view,
					int position, long id) {
				PlayUtils.turnToPlay(PlayMusicListActivity.this, DataUtils
						.getPlayList().get(position), false);
			}
		});
	}

	@Override
	protected void onResume() {
		super.onResume();
		myListAdapter.notifyDataSetChanged();
	}

	public class MyListAdapter extends BaseAdapter {
		private class buttonViewHolder {
			TextView musicName;
			ImageButton delete;
		}

		private List<MP3Music> musicList;
		private buttonViewHolder holder;

		public MyListAdapter() {
			musicList = DataUtils.getPlayList();
		}

		public int getCount() {
			return musicList.size();
		}

		public Object getItem(int position) {
			return musicList.get(position);
		}

		public long getItemId(int position) {
			return position;
		}

		public void removeItem(int position) {

			if (musicList.get(position).getName().equals(PlayService.name)) {
				PlayService.stop();
				TextView footer = (TextView) MainActivity.footer;
				footer.setText("���ڲ��ŵĸ���");
			}
			MP3Music mp3Music = musicList.remove(position);
			mp3Music.setPlayed(false);
			this.notifyDataSetChanged();
		}

		public View getView(final int position, View convertView,
				ViewGroup parent) {
			if (convertView != null) {
				holder = (buttonViewHolder) convertView.getTag();
			} else {
				convertView = View.inflate(PlayMusicListActivity.this,
						R.layout.playmusic_list_item_layout, null);
				holder = new buttonViewHolder();
				holder.musicName = (TextView) convertView
						.findViewById(R.id.text_playMusicName);
				holder.delete = (ImageButton) convertView
						.findViewById(R.id.button_delete);
				convertView.setTag(holder);
			}

			MP3Music mp3Music = DataUtils.getPlayList().get(position);
			if (mp3Music != null) {
				holder.musicName.setText(mp3Music.getName());
				holder.delete.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						removeItem(position);
					}
				});
			}
			return convertView;
		}
	}
}
