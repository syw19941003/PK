package syw.mp3player;

import syw.mp3player.util.DataUtils;

import com.atguigu.mp3player3.R;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Window;
/**
 * ��ʼ��ӭ����
 * @author xfzhang
 *
 */
public class StartActivity extends Activity {

	public static Context context;
	private ContentResolver resolver;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.start_layout);

		context = this;
		resolver = getContentResolver();

		new AsyncTask<Void, Void, Void>() {

			@Override
			protected Void doInBackground(Void... params) {
				if(DataUtils.getAllList().size()==0) {
					DataUtils.initAllMusicData(context, resolver);
				}
				return null;
			}

			@Override
			protected void onPostExecute(Void result) {
				startActivity(new Intent(context, MainActivity.class));
				finish();
			}
		}.execute();
	}
}
