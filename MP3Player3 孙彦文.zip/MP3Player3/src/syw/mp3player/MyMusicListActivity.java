package syw.mp3player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import syw.mp3player.bean.MP3Music;
import syw.mp3player.util.DataUtils;
import syw.mp3player.util.PlayUtils;

import android.app.ExpandableListActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.atguigu.mp3player3.R;

/**
 * �ҵ����ֲ����б�Activity
 * @author xfzhang
 *
 */
public class MyMusicListActivity extends ExpandableListActivity {

	// ��չListView
	private ExpandableListView myMusicListView;
	// ��һ���б�����list
	private List<Map<String, Object>> groupsList;
	// �ڶ�������list
	private List<List<MP3Music>> childsList;
	// ����������
	public static MyMusicListAdapter listAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mymusic_list_layout);
		init();
	}

	private void init() {
		myMusicListView = getExpandableListView();

		groupsList = new ArrayList<Map<String, Object>>();
		HashMap<String, Object> group1 = new HashMap<String, Object>();
		group1.put("name", "����");
		HashMap<String, Object> group2 = new HashMap<String, Object>();
		group2.put("name", "����");
		HashMap<String, Object> group3 = new HashMap<String, Object>();
		group3.put("name", "����");
		groupsList.add(group1);
		groupsList.add(group2);
		groupsList.add(group3);

		childsList = new ArrayList<List<MP3Music>>();
	
		childsList.add(DataUtils.getHappyList());
		childsList.add(DataUtils.getQuietList());
		childsList.add(DataUtils.getSadList());

		listAdapter = new MyMusicListAdapter();
		myMusicListView.setAdapter(listAdapter);
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v,//����ӿؼ�����
			int groupPosition, int childPosition, long id) {
		MP3Music mp3Music = childsList.get(groupPosition).get(childPosition);
		PlayUtils.turnToPlay(MyMusicListActivity.this, mp3Music, true);
		return true;
	}

	class MyMusicListAdapter extends BaseExpandableListAdapter {

		private class GroupViewsHolder {
			TextView groupText;
			ImageButton groupButton;
		}
		
		private class childViewsHolder {
			TextView childText;
			ImageButton childButton;
		}
		
		@Override
		public Object getChild(int groupPosition, int childPosition) {
			return childsList.get(groupPosition).get(childPosition);
		}
		@Override
		public long getChildId(int groupPosition, int childPosition) {
			return childPosition;
		}

		@Override
		public View getChildView(final int groupPosition,
				final int childPosition, boolean isLastChild, View convertView,
				ViewGroup parent) {
			childViewsHolder childHolder = null;
			if (convertView != null) {
				childHolder = (childViewsHolder) convertView.getTag();
			} else {
				childHolder = new childViewsHolder();
				convertView = View.inflate(MyMusicListActivity.this,
						R.layout.mymusic_childs_layout, null);
				childHolder.childText = (TextView) convertView
						.findViewById(R.id.text_childItem);
				childHolder.childButton = (ImageButton) convertView
						.findViewById(R.id.button_deleteChildItem);
				convertView.setTag(childHolder);
			}

			MP3Music mp3Music = childsList.get(groupPosition)
					.get(childPosition);
			if (mp3Music != null) {
				String name = mp3Music.getName();
				childHolder.childText.setText(name);
				childHolder.childButton
						.setOnClickListener(new View.OnClickListener() {//ɾ���б��и���
							@Override
							public void onClick(View v) {
								childsList.get(groupPosition).remove(childPosition);
								MyMusicListAdapter.this.notifyDataSetChanged();
							}
						});
			}
			return convertView;
		}
		@Override
		public int getChildrenCount(int groupPosition) {
			return childsList.get(groupPosition).size();
		}

		@Override
		public Object getGroup(int groupPosition) {
			return groupsList.get(groupPosition);

		}
		@Override
		public int getGroupCount() {
			return groupsList.size();
		}
		
		@Override
		public long getGroupId(int groupPosition) {
			return groupPosition;
		}
		
		@Override
		public View getGroupView(final int groupPosition, boolean isExpanded,
				View convertView, ViewGroup parent) {
			
			GroupViewsHolder groupHolder = null;
			if (convertView != null) {
				groupHolder = (GroupViewsHolder) convertView.getTag();
			} else {
				groupHolder = new GroupViewsHolder();
				convertView = View.inflate(MyMusicListActivity.this,
						R.layout.mymusic_groups_layout, null);
				groupHolder.groupText = (TextView) convertView
						.findViewById(R.id.text_groupItem);
				groupHolder.groupButton = (ImageButton) convertView
						.findViewById(R.id.button_playAll);
				convertView.setTag(groupHolder);
			}

			Map<String, Object> map = groupsList.get(groupPosition);
			if (map != null) {
				String name = (String) map.get("name");//��ȡ����
				groupHolder.groupText.setText(name);
				groupHolder.groupButton
						.setOnClickListener(new View.OnClickListener() {

							@Override
							public void onClick(View v) {//���������浽�����б��в����ŵ�һ�׸�
								PlayUtils.turnToPlayList(
										MyMusicListActivity.this,
										childsList.get(groupPosition));
							}
						});
			}

			return convertView;
		}

		@Override
		public boolean hasStableIds() {
			return false;
		}

		@Override
		public boolean isChildSelectable(int groupPosition, int childPosition) {
			return true;
		}

	}
}
