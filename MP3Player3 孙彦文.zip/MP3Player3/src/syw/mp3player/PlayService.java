package syw.mp3player;

import java.util.List;

import syw.mp3player.bean.MP3Music;
import syw.mp3player.util.DataUtils;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.IBinder;


public class PlayService extends Service {

	public static MediaPlayer player;
	public static String name;
	static String path;
	static String artist;
	// ����״̬
	// 0. ��ʼ״̬
	// 1. ���ڲ���
	// 2. ��ͣ
	public static int playStatus = 0;
	// ��ǰ���ŵ��������б��е��±�
	public static int musicPosition;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		if (player == null) {
			player = new MediaPlayer();
			player.setOnCompletionListener(new OnCompletionListener() {

				public void onCompletion(MediaPlayer mp) {
					player.reset();

					List<MP3Music> list = DataUtils.getPlayList();
					getNextMusicPostion();
					MP3Music mp3Music = list.get(musicPosition);
					path = mp3Music.getPath();
					name = mp3Music.getName();
					artist = mp3Music.getArtist();
					try {
						play();
					} catch (Exception e) {
						System.out.println("�����д���");
					}

				}
			});
		}
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		
		name = intent.getStringExtra("name");
		path = intent.getStringExtra("path");
		artist = intent.getStringExtra("artist");
		try {
			play();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return super.onStartCommand(intent, flags, startId);
	}

	private void play() throws Exception {
		player.reset();
		player.setDataSource(path);
		player.prepareAsync();
		player.setOnPreparedListener(new OnPreparedListener() {

			public void onPrepared(MediaPlayer mp) {// ׼������
				if (player != null) {
					player.start();
					playStatus = 1;
					MainActivity.footer.setText(name);
				}
			}
		});
	}

	public static void pause() {
		if (playStatus == 1) {
			player.pause();
			playStatus = 2;
		}
	}

	public static void goon() {
		if (playStatus == 2) {
			player.start();
			playStatus = 1;
		}
	}

	public static void stop() {
		if (playStatus != 0) {
			player.stop();
			playStatus = 0;
		}
	}

	public static int getNextMusicPostion() {
		musicPosition = musicPosition<DataUtils.getPlayList().size()-1 ? musicPosition+1 : 0;
		return musicPosition;
	}

	public static int getPreMusicPosition() {
		musicPosition = musicPosition == 0 ? DataUtils.getPlayList().size()-1 : musicPosition-1;
		return musicPosition;
	}

}
