package syw.mp3player.bean;

/**
 * ������Ϣ����
 * 
 * 
 */
public class MP3Music {

	private int id;// ��ʶid
	private String name; // ����
	private String path; // �ļ�·��
	private String artist; // ������

	private boolean played; // �Ƿ��ڲ����б���
	private boolean happy; // �Ƿ��ڿ��ĸ赥��
	private boolean quiet; // �Ƿ��ڰ����赥��
	private boolean sad; // �Ƿ������˸赥��

	public MP3Music(int id, String name, String path, String artist,
			boolean played, boolean happy, boolean quiet, boolean sad) {
		super();
		this.id = id;
		this.name = name;
		this.path = path;
		this.artist = artist;
		this.played = played;
		this.happy = happy;
		this.quiet = quiet;
		this.sad = sad;
	}

	public MP3Music() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public boolean isPlayed() {
		return played;
	}

	public void setPlayed(boolean played) {
		this.played = played;
	}

	public boolean isHappy() {
		return happy;
	}

	public void setHappy(boolean happy) {
		this.happy = happy;
	}

	public boolean isQuiet() {
		return quiet;
	}

	public void setQuiet(boolean quiet) {
		this.quiet = quiet;
	}

	public boolean isSad() {
		return sad;
	}

	public void setSad(boolean sad) {
		this.sad = sad;
	}

	@Override
	public String toString() {
		return "MP3Music [id=" + id + ", name=" + name + ", path=" + path
				+ ", artist=" + artist + ", played=" + played + ", happy="
				+ happy + ", quiet=" + quiet + ", sad=" + sad + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((path == null) ? 0 : path.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MP3Music other = (MP3Music) obj;
		if (path == null) {
			if (other.path != null)
				return false;
		} else if (!path.equals(other.path))
			return false;
		return true;
	}

}
