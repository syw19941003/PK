package syw.mp3player;

import java.io.File;
import java.util.List;

import syw.mp3player.bean.MP3Music;
import syw.mp3player.bean.SongLyric;
import syw.mp3player.util.DataUtils;
import syw.mp3player.view.LyricView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.atguigu.mp3player3.R;

public class PlayMusicActivity extends Activity {

	private TextView musicTextView;
	private Button lastButton;
	private Button playButton;
	private Button nextButton;
	private SeekBar seekBar;
	private ImageView musicImage;
	private TextView positionTV;
	private TextView maxTV;

	private String name;
	private String path;
	private String artist;

	private Handler handler = new Handler();
	private Runnable runnable;
	private boolean isChangingSeekbar;

	private SongLyric lrc;
	private LyricView lrcView;
	private long time = 0;
	private LinearLayout lrcLayout;
	private String lrcPath;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.playmusic_layout);

		positionTV = (TextView) findViewById(R.id.tv_position);
		maxTV = (TextView) findViewById(R.id.tv_max);
		musicTextView = (TextView) findViewById(R.id.text_musicName);
		lastButton = (Button) findViewById(R.id.button_last);
		playButton = (Button) findViewById(R.id.button_play);
		nextButton = (Button) findViewById(R.id.button_next);
		seekBar = (SeekBar) findViewById(R.id.seekBar);
		musicImage = (ImageView) findViewById(R.id.image_pic);
		lrcLayout = (LinearLayout) findViewById(R.id.lrc_layout);
		lrcView = new LyricView(lrcLayout.getContext());
		lrcLayout.addView(lrcView);

		lastButton.setOnClickListener(buttonListener);
		playButton.setOnClickListener(buttonListener);
		nextButton.setOnClickListener(buttonListener);
		seekBar.setOnSeekBarChangeListener(seekBarListener);

		runnable = new Runnable() {
			public void run() {
				if (PlayService.playStatus == 1) {
					//���ý�����״̬
					seekBar.setMax(PlayService.player.getDuration());
					seekBar.setProgress(PlayService.player.getCurrentPosition());
					if (new File(lrcPath).exists()) {
						lrc = new SongLyric(lrcPath);
						lrc.setMaxTime(PlayService.player.getDuration());
						lrcView.setLyric(lrc);
						time = PlayService.player.getCurrentPosition();
						lrcView.setTime(time);
						lrcView.postInvalidate();
						Log.e("TAG", "------");
						positionTV.setText(SongLyric.longToString((int) time));
						maxTV.setText(SongLyric.longToString((int) lrc
								.getMaxTime()));
					}
				}
				if (!name.equals(PlayService.name)) {
					name = PlayService.name;
					path = PlayService.path;
					artist = PlayService.artist;
					musicTextView.setText(name);
					musicImage.setImageResource(R.drawable.pic);
					lrcPath = path.substring(0, path.length() - 4) + ".lrc";
				}
				handler.postDelayed(this, 50);
			}
		};

		if (DataUtils.getPlayList().isEmpty()) {
			name = null;
			path = null;
		} else {
			if (PlayService.playStatus != 0) {
				name = PlayService.name;
				path = PlayService.path;
				artist = PlayService.artist;
				System.out.println(path);
				lrcPath = path.substring(0, path.length() - 4) + ".lrc";
				System.out.println(lrcPath);
				musicTextView.setText(name);

				if (PlayService.playStatus == 1) {
					handler.post(runnable);
					playButton.setBackgroundResource(R.drawable.pause_select);
				}
				if (PlayService.playStatus == 2) {
					playButton.setBackgroundResource(R.drawable.play_select);
				}

				for (int i = 0; i < DataUtils.getPlayList().size(); i++) {
					if (name.equals(DataUtils.getPlayList().get(i).getName())) {
						PlayService.musicPosition = i;
						break;
					}
				}
			} else {
				getMusicInfo(0);
			}
		}
	}

	@Override
	protected void onResume() {
		if (PlayService.playStatus == 1) {
			handler.post(runnable);
		}
		super.onResume();
	}

	@Override
	protected void onStop() {
		handler.removeCallbacks(runnable);
		super.onStop();
	}

	private void getMusicInfo(int position) {
		List<MP3Music> playList = DataUtils.getPlayList();
		MP3Music mp3Music = playList.get(position);
		name = mp3Music.getName();
		path = mp3Music.getPath();
		artist = mp3Music.getArtist();
		lrcPath = path.substring(0, path.lastIndexOf(".")) + ".lrc";
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, 0, 0, "ֹͣ");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case 0:
			PlayService.stop();
			handler.removeCallbacks(runnable);
			seekBar.setProgress(0);
			playButton.setBackgroundResource(R.drawable.play_select);
			MainActivity.footer.setText("���ڲ��ŵĸ���");
			break;
		default:
			break;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	private View.OnClickListener buttonListener = new View.OnClickListener() {
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.button_last:
				last();
				break;
			case R.id.button_play:
				playOrPause();
				break;
			case R.id.button_next:
				next();
				break;
			default:

				break;
			}
		}
	};

	private void playOrPause() {
		if (PlayService.playStatus == 0) {
			if (name == null) {
				Toast.makeText(PlayMusicActivity.this, "û�и���", 0).show();
			} else {
				playMusic();
			}
		} else if (PlayService.playStatus == 1) {
			handler.removeCallbacks(runnable);
			PlayService.pause();
			playButton.setBackgroundResource(R.drawable.play_select);
		} else if (PlayService.playStatus == 2) {
			PlayService.goon();
			handler.post(runnable);
			playButton.setBackgroundResource(R.drawable.pause_select);
		}
	}

	private void last() {
		if (DataUtils.getPlayList().size() > 1) {
			handler.removeCallbacks(runnable);
			PlayService.stop();
			getMusicInfo(PlayService.getPreMusicPosition());
			playMusic();
		} else {
			Toast.makeText(PlayMusicActivity.this, "û����һ��", 0).show();
		}
	}

	private void next() {

		if (DataUtils.getPlayList().size() > 1) {
			handler.removeCallbacks(runnable);
			PlayService.stop();
			getMusicInfo(PlayService.getNextMusicPostion());
			playMusic();
		} else {
			Toast.makeText(PlayMusicActivity.this, "û����һ��", 0).show();
		}
	}

	private void playMusic() {
		Intent intent = new Intent(PlayMusicActivity.this, PlayService.class);
		intent.putExtra("name", name);
		intent.putExtra("path", path);
		intent.putExtra("artist", artist);
		startService(intent);

		playButton.setBackgroundResource(R.drawable.pause_select);
		musicTextView.setText(name);
		MainActivity.footer.setText(name);

		handler.post(runnable);
	}

	private OnSeekBarChangeListener seekBarListener = new OnSeekBarChangeListener() {

		public void onProgressChanged(SeekBar seekBar, int progress,
				boolean fromUser) {

		}

		public void onStartTrackingTouch(SeekBar seekBar) {
			if (PlayService.playStatus != 0) {
				handler.removeCallbacks(runnable);
				isChangingSeekbar = true;
			}
		}

		public void onStopTrackingTouch(SeekBar seekBar) {
			if (isChangingSeekbar) {
				PlayService.player.seekTo(seekBar.getProgress());
				handler.post(runnable);
				isChangingSeekbar = false;
			}
		}
	};
}
