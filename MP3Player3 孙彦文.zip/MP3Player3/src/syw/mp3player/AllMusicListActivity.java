package syw.mp3player;

import java.util.List;

import syw.mp3player.bean.MP3Music;
import syw.mp3player.util.DataUtils;
import syw.mp3player.util.MusicBC;
import syw.mp3player.util.PlayUtils;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.atguigu.mp3player3.R;

/**
 * �������ֵ��б�Activity
 * @author xfzhang
 *
 */
public class AllMusicListActivity extends Activity {

	private ListView listView;
	public static MyListAdapter listAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.allmusic_list_layout);
		
		init();//���һ���������ϲ���벥���б�
	}

	private void init() {
		listView = (ListView) findViewById(android.R.id.list);
		listAdapter = new MyListAdapter();
		listView.setAdapter(listAdapter);//���Ӳ����б���ϲ��
		listView.setOnItemClickListener(new OnItemClickListener() {//����б���itemviewһ��Ļص�
			public void onItemClick(AdapterView<?> adapterView, View view,
					int position, long id) {
				
				System.out.println("---");
				PlayUtils.turnToPlay(AllMusicListActivity.this, DataUtils
						.getAllList().get(position), true);
				Log.e("TAG", DataUtils.getAllList().get(position)+"");
				
			}
		});
	}

	public class MyListAdapter extends BaseAdapter {

		private class buttonViewHolder {
			TextView musicName;
			ImageButton add;
			ImageButton collect;
		}

		private List<MP3Music> mAllList;

		public MyListAdapter() {
			this.mAllList = DataUtils.getAllList();
		}

		public int getCount() {
			return mAllList.size();
		}

		public Object getItem(int position) {
			return mAllList.get(position);
		}

		public long getItemId(int position) {
			return position;
		}

		public void removeItem(int position) {
			mAllList.remove(position);
			this.notifyDataSetChanged();
		}

		public View getView(final int position, View convertView,
				ViewGroup parent) {
			buttonViewHolder holder = null;
			if (convertView != null) {
				holder = (buttonViewHolder) convertView.getTag();
			} else {
				convertView = View.inflate(AllMusicListActivity.this,
						R.layout.allmusic_list_item_layout, null);
				holder = new buttonViewHolder();
				holder.musicName = (TextView) convertView
						.findViewById(R.id.text_musicName);
				holder.add = (ImageButton) convertView
						.findViewById(R.id.button_add);
				holder.collect = (ImageButton) convertView
						.findViewById(R.id.button_collect);
				convertView.setTag(holder);
			}

			MP3Music mp3Music = mAllList.get(position);

			if (mp3Music != null) {
				holder.musicName.setText(mp3Music.getName());
				holder.add.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						MP3Music mp3Music = DataUtils.getAllList()
								.get(position);
						boolean b = PlayUtils.addMusicToPlayList(
								AllMusicListActivity.this, mp3Music);
						if (b)
							PlayMusicListActivity.myListAdapter
									.notifyDataSetChanged();
					}
				});//���Ӳ����б�
				holder.collect.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {//����ϲ������
						new AlertDialog.Builder(AllMusicListActivity.this)
							.setIcon(R.drawable.collect)
							.setTitle("����ѡ���ղ��б�")
							.setItems(new String[] { "����", "����", "����" },
								new DialogInterface.OnClickListener() {

									public void onClick(DialogInterface dialog,
											int which) {
										MP3Music mp3Music = DataUtils
												.getAllList().get(position);
										boolean b = false;
										switch (which) {
										case 0:
											b = DataUtils
													.addToHappyList(mp3Music);
											break;
										case 1:
											b = DataUtils
													.addToQuietList(mp3Music);
											break;
										case 2:
											b = DataUtils
													.addToSadList(mp3Music);
											break;
										default:
											b = false;
											break;
										}
										if (b) {
											MyMusicListActivity.listAdapter
													.notifyDataSetChanged();
										}

									}
								})
								.show();
					}
				});
			}
			return convertView;
		}
	}
	
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			DataUtils.backDialog(this);
		}
		return false;
	};
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, 1, 0, "����ɨ������");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case 1:
			IntentFilter intentFilter = new IntentFilter();  
			intentFilter.addAction(Intent.ACTION_MEDIA_SCANNER_FINISHED); 
			intentFilter.addAction(Intent.ACTION_MEDIA_SCANNER_STARTED);   
			intentFilter.addDataScheme("file"); 
	        
			MusicBC musicBC = new MusicBC();
			registerReceiver(musicBC, intentFilter);
			DataUtils.scanMusic(this);
			break;
		default:
			break;
		}
		return super.onMenuItemSelected(featureId, item);
	}
}
