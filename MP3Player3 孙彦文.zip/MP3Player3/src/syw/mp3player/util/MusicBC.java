package syw.mp3player.util;

import syw.mp3player.AllMusicListActivity;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Toast;

public class MusicBC extends BroadcastReceiver {

	private AlertDialog dialog = null;
	private int count1;
	private int count2;
	private int count;

	@Override
	public void onReceive(final Context context, Intent intent) {

		String action = intent.getAction();

		if (Intent.ACTION_MEDIA_SCANNER_STARTED.equals(action)) {
			Cursor c1 = context.getContentResolver().query(
					MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null,
					null, null);
			count1 = c1.getCount();

			Log.e("TAG", "count---->>>>" + count1);
			dialog = new AlertDialog.Builder(context).setMessage("����ɨ��洢��...")
					.show();
			c1.close();
		} else if (Intent.ACTION_MEDIA_SCANNER_FINISHED.equals(action)) {
			Cursor c2 = context.getContentResolver().query(
					MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null,
					null, null);
			count2 = c2.getCount();
			Log.e("RG", "count---->>>>>>");

			count = count2 - count1;
			Log.e("TAG", "count2-count---->>>>" + count);
			//dialog.dismiss();
			if (count > 0) {
				Toast.makeText(context, "������" + count + "�׸���",
						Toast.LENGTH_LONG).show();
			} 
			
			new AsyncTask<Void, Void, Void>() {

				@Override
				protected Void doInBackground(Void... params) {
					DataUtils.updateList();
					DataUtils.initAllMusicData(context, context.getContentResolver());
					return null;
				}
				
				protected void onPostExecute(Void result) {
					AllMusicListActivity.listAdapter.notifyDataSetChanged();
					context.unregisterReceiver(MusicBC.this);
					dialog.dismiss();
					
				}
			}.execute();
		}
		
	}
}
