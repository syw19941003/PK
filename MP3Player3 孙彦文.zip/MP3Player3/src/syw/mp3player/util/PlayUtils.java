package syw.mp3player.util;

import java.io.File;
import java.util.List;

import syw.mp3player.PlayMusicListActivity;
import syw.mp3player.PlayService;
import syw.mp3player.bean.MP3Music;

import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.widget.Toast;

import com.atguigu.mp3player3.R;

/**
 * ���ŵĹ�����
 * 
 * 
 */
public class PlayUtils {
	/**
	 * ���Ӹ���ʵ����󵽲����б�
	 * 
	 * @param context
	 * @param mp3Music
	 * @return
	 */
	public static boolean addMusicToPlayList(Context context, MP3Music mp3Music) {
		if (new File(mp3Music.getPath()).exists()) {
			boolean success = DataUtils.addToPlayList(mp3Music);
			if (!success) {
				Toast.makeText(context, "�����б��Ѵ���", 0).show();
			} else {
				Toast.makeText(context, "����OK!", 0).show();
			}
			return true;
		} else {
			Toast.makeText(context, R.string.text_gequbucunzai, 0).show();
			return false;
		}

	}

	/**
	 * תΪ����ָ���ĸ���
	 * 
	 * @param map
	 * @param context
	 */
	public static void turnToPlay(Context context, MP3Music mp3Music,
			boolean add) {
		if (new File(mp3Music.getPath()).exists()) {
			if (mp3Music.getName().equals(PlayService.name)
					&& PlayService.playStatus == 1) {
				Toast.makeText(context, "���ڲ���...", 0).show();
			} else {
				if (add) {
					boolean success = DataUtils.addToPlayList(mp3Music);
					if (success)//������ӳɹ����򲥷ű�����
						PlayMusicListActivity.myListAdapter
								.notifyDataSetChanged();
				}
				Intent intent = new Intent(context, PlayService.class);
				intent.putExtra("name", mp3Music.getName());
				intent.putExtra("path", mp3Music.getPath());
				intent.putExtra("artist", mp3Music.getArtist());
				context.startService(intent);
			}
		} else {
			Toast.makeText(
					context,
					mp3Music.getName()
							+ context.getResources().getString(
									R.string.text_gequbucunzai), 0).show();
		}
	}

	/**
	 * ������������ӵ������б�, ����ʼ���ŵ�һ��
	 * 
	 * @param context
	 * @param musicList
	 */
	public static void turnToPlayList(Context context, List<MP3Music> list) {

		if (!list.isEmpty()) {
			DataUtils.addToPlayList(list);
			turnToPlay(context, list.get(0), false);
		} else {
			Toast.makeText(context, "���ղؼ���û������", 0).show();
		}
	}

	/**
	 * �õ�����ļ�·��
	 * 
	 * @param context
	 * @param musicName
	 * @param musicPath
	 * @return
	 */
	public static String getLrcFile(Context context, String musicName,
			String musicPath) {
		String lrcFileName = musicName + ".lrc";
		String lrcFilePath = musicPath.substring(0, -(musicName.length() + 4))
				+ lrcFileName;
		if (new File(lrcFilePath).exists()) {
			return lrcFilePath;
		} else {
			return null;
		}
	}
}
