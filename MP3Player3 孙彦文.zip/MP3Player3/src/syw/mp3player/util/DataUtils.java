package syw.mp3player.util;

import java.util.ArrayList;
import java.util.List;

import syw.mp3player.AllMusicListActivity;
import syw.mp3player.PlayService;
import syw.mp3player.bean.MP3Music;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.webkit.WebChromeClient.CustomViewCallback;


public final class DataUtils {

	private static List<MP3Music> allList = new ArrayList<MP3Music>();
	private static List<MP3Music> happyList = new ArrayList<MP3Music>();
	private static List<MP3Music> quietList = new ArrayList<MP3Music>();
	private static List<MP3Music> sadList = new ArrayList<MP3Music>();
	private static List<MP3Music> playList = new ArrayList<MP3Music>();
	private static Context context;

	public static List<MP3Music> getAllList() {
		return allList;
	}

	public static List<MP3Music> getHappyList() {
		return happyList;
	}

	public static List<MP3Music> getQuietList() {
		return quietList;
	}

	public static List<MP3Music> getSadList() {
		return sadList;
	}

	public static List<MP3Music> getPlayList() {
		return playList;
	}

	public static Context getContext() {
		return context;
	}

	public static void initAllMusicData(Context context,
			ContentResolver resolver) {

		DataUtils.context = context;
		DBHelper dbHelper = new DBHelper(context);
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		// db.execSQL("delete from mp3_music");
		//���뵱ǰ��������
		Cursor cursor = db.query("mp3_music", null, null, null, null, null,
				null);
		while (cursor.moveToNext()) {
			int id = cursor.getInt(cursor.getColumnIndex("_id"));
			String name = cursor.getString(cursor.getColumnIndex("name"));
			String artist = cursor.getString(cursor.getColumnIndex("artist"));
			String path = cursor.getString(cursor.getColumnIndex("path"));
			boolean played = cursor.getInt(cursor.getColumnIndex("played")) == 1;
			boolean happy = cursor.getInt(cursor.getColumnIndex("happy")) == 1;
			boolean quiet = cursor.getInt(cursor.getColumnIndex("quiet")) == 1;
			boolean sad = cursor.getInt(cursor.getColumnIndex("sad")) == 1;
			MP3Music mp3Music = new MP3Music(id, name, path, artist, played,
					happy, quiet, sad);

			allList.add(mp3Music);

			if (mp3Music.isPlayed()) {
				playList.add(mp3Music);
			}
			if (mp3Music.isHappy()) {
				happyList.add(mp3Music);
			}
			if (mp3Music.isQuiet()) {
				quietList.add(mp3Music);
			}
			if (mp3Music.isSad()) {
				sadList.add(mp3Music);
			}

		}

		cursor = resolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
				null, null, null, null);//��ȡϵͳ������
		while (cursor.moveToNext()) {
			// �����ļ���·��
			String path = cursor.getString(cursor
					.getColumnIndex(MediaStore.Audio.Media.DATA));
			// ����������
			String name = cursor.getString(cursor
					.getColumnIndex(MediaStore.Audio.Media.TITLE));
			// �����ĸ�����
			String artist = cursor.getString(cursor
					.getColumnIndex(MediaStore.Audio.Media.ARTIST));
			MP3Music mp3Music = new MP3Music(0, name, path, artist, false,
					false, false, false); 
			Log.e("TAG", name + "_" + artist + "_" + path);
			if (!allList.contains(mp3Music)) {
				ContentValues values = new ContentValues();
				values.put("name", name);
				values.put("path", path);
				values.put("artist", artist);
				long id = db.insert("mp3_music", null, values);//����ȡ�����ݱ��浽�Լ��Ŀ���

				mp3Music.setId((int) id);
				allList.add(mp3Music);
			}
		}
		db.close();
	}
	
	public static boolean addToHappyList(MP3Music mp3Music) {
		mp3Music.setHappy(true);
		return addToList(happyList, mp3Music, "happy", mp3Music.getId());
	}

	public static boolean addToQuietList(MP3Music mp3Music) {
		mp3Music.setQuiet(true);
		return addToList(quietList, mp3Music, "quiet", mp3Music.getId());
	}

	public static boolean addToSadList(MP3Music mp3Music) {
		mp3Music.setSad(true);
		return addToList(sadList, mp3Music, "sad", mp3Music.getId());
	}

	public static boolean addToPlayList(MP3Music mp3Music) {
		mp3Music.setPlayed(true);
		return addToList(playList, mp3Music, "played", mp3Music.getId());
	}

	public static void addToPlayList(List<MP3Music> musicList) {
		for (MP3Music mp3Music : musicList) {
			addToPlayList(mp3Music);
		}
	}

	/**
	 * ��һ���������ӵ�ĳ���б���
	 * 
	 * @param list
	 * @param mp3Music
	 * @param column
	 * @param id
	 * @return
	 */
	private static boolean addToList(List<MP3Music> list, MP3Music mp3Music,
			String column, int id) {
		if (list.contains(mp3Music))
			return false;

		list.add(mp3Music);

		/*DBHelper dbHelper = new DBHelper(context);
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(column, 1);
		db.update("mp3_music", values, "_id=?", new String[] { id + "" });*/
		return true;
	}

	public static void updateList() {
		DBHelper dbHelper = new DBHelper(context);
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.execSQL("delete from mp3_music");
		for (MP3Music mp3Music : allList) {
			ContentValues values = new ContentValues();
			values.put("name", mp3Music.getName());
			values.put("path", mp3Music.getName());
			values.put("artist", mp3Music.getName());
			values.put("played", mp3Music.getName());
			values.put("happy", mp3Music.getName());
			values.put("quiet", mp3Music.getName());
			values.put("sad", mp3Music.getName());
		}
		allList.clear();
		happyList.clear();
		quietList.clear();
		sadList.clear();
		playList.clear();
		
	}

	public static void scanMusic(Context ctx) {
		
		ctx.sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED,
				Uri.parse("file://"
						+ Environment.getExternalStorageDirectory()
								.getAbsolutePath())));
		Log.e("TAG", "���͹㲥 !");
	}
	
	public static void backDialog(final Activity activity) {
		AlertDialog.Builder builder = new Builder(activity);
		builder.setMessage("ȷ���˳���");
		builder.setTitle("��ʾ");
		builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {

			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				activity.finish();
				new AsyncTask<Void, Void, Void>(){
					@Override
					protected Void doInBackground(Void... params) {
						if (PlayService.playStatus != 0) {
							PlayService.stop();
						}
						DataUtils.updateList();
						return null;
					}
					
				}.execute();
				
			}
		});
		builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {

			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}

		});

		builder.create().show();
	}
}
